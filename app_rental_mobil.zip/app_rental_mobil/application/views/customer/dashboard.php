<!-- Page Content -->
<!-- Banner Starts Here -->
<div class="main-banner header-text">
  <div class="container-fluid">
    <div class="owl-banner owl-carousel">
      <div class="item">
        <img src="<?= base_url('assets/assets_shop') ?>/images/product-1-720x480.jpg" alt="">
        <div class="item-content">
          <div class="main-content">
            <div class="meta-category">
              <span>
                <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-cog"></i> A
              </span>
            </div>
            <a href="fleet.html"><h4>Beli Mobil</h4></a>
            <ul class="post-info">
              <li>Belum di Isi</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="item">
        <img src="<?= base_url('assets/assets_shop') ?>/images/product-2-720x480.jpg" alt="">
        <div class="item-content">
          <div class="main-content">
            <div class="meta-category">
              <span>
                <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-cog"></i> A
              </span>
            </div>
            <a href="fleet.html"><h4>Jual Mobil</h4></a>
            <ul class="post-info">
              <li>ssasafa</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="item">
        <img src="<?= base_url('assets/assets_shop') ?>/images/product-3-720x480.jpg" alt="">
        <div class="item-content">
          <div class="main-content">
            <div class="meta-category">
              <span>
                <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-cog"></i> A
              </span>
            </div>
            <a href="fleet.html"><h4>Rental Mobil</h4></a>
            <ul class="post-info">
              <li>aadasdasda</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="item">
        <img src="<?= base_url('assets/assets_shop') ?>/images/product-4-720x480.jpg" alt="">
        <div class="item-content">
          <div class="main-content">
            <div class="meta-category">
              <span>
                <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-cog"></i> A
              </span>
            </div>
            <a href="fleet.html"><h4>Pasang Iklan</h4></a>
            <ul class="post-info">
              <li>afazxvzxczxczc</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="item">
        <img src="<?= base_url('assets/assets_shop') ?>/images/product-5-720x480.jpg" alt="">
        <div class="item-content">
          <div class="main-content">
            <div class="meta-category">
              <span>
                <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-cog"></i> A
              </span>
            </div>
            <a href="fleet.html"><h4>Pasang Iklan</h4></a>
            <ul class="post-info">
              <li>asadasdadsdsa</li>
            </ul>
          </div>
        </div>
      </div>
      <div class="item">
        <img src="<?= base_url('assets/assets_shop') ?>/images/product-6-720x480.jpg" alt="">
        <div class="item-content">
          <div class="main-content">
            <div class="meta-category">
              <span>
                <i class="fa fa-user"></i> 5 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-briefcase"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-sign-out"></i> 4 &nbsp;&nbsp;&nbsp;
                <i class="fa fa-cog"></i> A
              </span>
            </div>
            <a href="fleet.html"><h4>Pasang Iklan</h4></a>
            <ul class="post-info">
              <li>asdasda</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Banner Ends Here -->

<section class="blog-posts grid-system">
  <div class="container">
    <div class="all-blog-posts">
      <h2 class="text-center">Offers</h2>
      <br>
      <div class="row">
        <div class="col-md-4 col-sm-6">
          <div class="blog-post">
            <div class="blog-thumb">
              <img src="<?= base_url('assets/assets_shop') ?>/images/offer-1-720x480.jpg" alt="">
            </div>
            <div class="down-content">
              <strong>from</strong> <span> Rp. 1.200.000</span> <strong>per weekend</strong>
              <a href="offers.html"><h4>Pasang Iklan</h4></a>
              <p>Anda Bisa memasang ikla disini</p>
              <div class="post-options">
                <div class="row">
                  <div class="col-lg-12">
                    <ul class="post-tags">
                      <li><i class="fa fa-bullseye"></i></li>
                      <li><a href="offers.html">View More</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          <div class="blog-post">
            <div class="blog-thumb">
              <img src="<?= base_url('assets/assets_shop') ?>/images/offer-2-720x480.jpg" alt="">
            </div>
            <div class="down-content">
              <strong>from</strong> <span> Rp. 1.200.000</span> <strong>per weekend</strong>
              <a href="offers.html"><h4>Pasang Iklan</h4></a>
              <p>Anda Bisa memasang ikla disini</p>
              <div class="post-options">
                <div class="row">
                  <div class="col-lg-12">
                    <ul class="post-tags">
                      <li><i class="fa fa-bullseye"></i></li>
                      <li><a href="offers.html">View More</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          <div class="blog-post">
            <div class="blog-thumb">
              <img src="<?= base_url('assets/assets_shop') ?>/images/offer-3-720x480.jpg" alt="">
            </div>
            <div class="down-content">
              <strong>from</strong> <span> Rp. 1.200.000</span> <strong>per weekend</strong>
              <a href="offers.html"><h4>Pasang Iklan</h4></a>
              <p>Anda Bisa memasang ikla disini</p>
              <div class="post-options">
                <div class="row">
                  <div class="col-lg-12">
                    <ul class="post-tags">
                      <li><i class="fa fa-bullseye"></i></li>
                      <li><a href="offers.html">View More</a></li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="call-to-action">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="main-content">
          <div class="row">
            <div class="col-lg-8">
              <span>Jasa Pembuatan Website Aplikasi</span>
              <h4>khanzaantarariq@gmail.com</h4>
            </div>
            <div class="col-lg-4">
              <div class="main-button">
                <a href="https://www.instagram.com/khanzaantarariq/">Hubungi Kami</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="blog-posts grid-system">
  <div class="container">
    <div class="all-blog-posts">
      <h2 class="text-center">Blog</h2>
      <br>
      <div class="row">
        <div class="col-md-4 col-sm-6">
          <div class="blog-post">
            <div class="blog-thumb">
              <img src="https://pict-b.sindonews.net/dyn/620/content/2019/08/09/158/1428362/kematian-tony-stark-diputuskan-sebelum-syuting-avengers-endgame-Bcm-thumb.jpg" alt="">
            </div>
            <div class="down-content">
              <a href="blog-details.html"><h4>Tony Stark dan Iron-Man</h4></a>
              
              <p>Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend.</p>

              <ul class="post-info">
                <li><a href="#">Tony Stark</a></li>
                <li><a href="#">10.02.2022 10:20</a></li>
                <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          <div class="blog-post">
            <div class="blog-thumb">
              <img src="https://asset.kompas.com/crops/uYzdJo-J64PlECOY2FP4ttczQ78=/255x119:1271x796/750x500/data/photo/2021/08/11/6112e2657d49e.jpg" alt="">
            </div>
            <div class="down-content">
              <a href="blog-details.html"><h4>Lionel Messi bergabung ke Squad Paris Saint German, usai kontrak Habis dari Barcelona</h4></a>
              
              <p>Messi Joi PSG.</p>

              <ul class="post-info">
                <li><a href="#">Lionel Messi</a></li>
                <li><a href="#">13.03.2022 13:20</a></li>
                <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-md-4 col-sm-6">
          <div class="blog-post">
            <div class="blog-thumb">
              <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoGCBMTExcVFRMYGBcZGh8aGxkaGSAZHBoaIRkZGRkZGBkfHysjGhwoHxkYJDUkKCwuMjIyGSE3PDcxOysxMi4BCwsLDw4PHRERHTEoISgxMzExMTExMTExMzExMzEyMTExMzExMTEyMTIxMTExMTExMTExMTExMTExMTExMTExMf/AABEIALEBHQMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAGAAIDBAUBBwj/xABDEAACAQIEAwYDBQUHAwQDAAABAhEAAwQSITEFQVEGEyJhcZEygaEUI0JS0WKSscHwBxUWM3KC4SRTc5Oys/FUg4T/xAAZAQACAwEAAAAAAAAAAAAAAAAAAwECBAX/xAAoEQACAgEDAwQCAwEAAAAAAAAAAQIRAwQSISIxQRNRYXEUMpGhwbH/2gAMAwEAAhEDEQA/API2UgwRqNCOh5iuUSds8GO9a9aRgj6vIjI8lWBjTUjbkZmh1tquBNhMS9ucpGsSCoYGNRIINTLxBgZyIP8ASCntkIohv9jtAbd4tO33eYA5S0OynwAZYLEaZlqriuyV9CoD2znuG2up3AuGTAMCLbabiRpQRwD1xsxJO5M7k/U6n502tDi/CLuHKd4B4xKlTMjSfMbjcc6jwOBa78O8xH9etVlJRVsbjxyyS2wVsrJcZdQzA+RI/hU54jfIKm9cIIIILsQQQQQQT0J96mt8LuM+RQC0ExMaCOvqKe/AsSDHcknyZT/OpTTVoicJQltkqaKNi5lMxV5+KszIzCcjKd/ysGjbSs6n27ZYgAEk6AASSeQAG5qrhFu2uS8dROEHBPh/6Ew7VqTLWPxBiMwIMWyBoQPxZT6KBQ5j7wuXXcCAzEgdFnwj5CBXMRYa2xR1KspgqRBB8xTYq4ign7NXcuFLJiLVq8t5mVbpUK6lLassttsNfLlNW7K3Ww9571zDjJZuqgtm1ndnUgybemXyG5jTShXC467bBFtyoJkgRE7TBpXMXcYEMQZ/ZWfeJFAUVCKKw3CTlkFds+l2ZjUqQcvxRvymNaF4pRQAT28Nwpip7whcviDG4GzZreu0fD3mx3jQ0PcXt2luuLRzW58BmZEA6895qGK5FAUb9m3a7qT8fTyjp0/5rR4Xw6ycPbdktGbbuxNsFhlPMz0I19KEKUeVKx49l82bNVqvXUUlVfJs9sMMlq6iKqAhJbIuUSWIg9SCpqbslYZ7WLCo7jJbLIhys6d4S6qYO4G0aiRzrAAq9wfiLYcsVz+IAeC41o6Gd13+dNMYRdmLdq7iF7jC3bbJczG4bhKpbAOZWGXdh4cuu++9BtblztDeM+O7/wCvc/XWsWKAQQcLscPNlDdb738YZrgX/MI0yKdckn1CdTU4t8J08TaOpObvdUyLmAyjfNm6c40ihilQFGl2jOFJt/ZhAy+P4/i02z8t9vbaZeDYi0qHPE5TE9Z00rHIrmWl5Ib1Rp02d4ZN1dqgn7P4uwnel7wQl7eXXdZh+XQ7+RrvHuI2Gw7ql3NcYgQCSIz6kdRlWP8AdQvFKrxVKhWSW+Tk/LsbRjdusLFk4fHWrZazbW5ba4qsGVRBBgkHkRptQfVteJXgoUXCFAgDQaDYTE1Itm/xS+v2S6LmLF++5tgBSWVEVgYBgCdJJ5wPmJFanvYm4whnYjoSSPaoooBGqe0OJyhc4AAAHgWQFACwSCQRqQeRY9agXjWKExecSZMGJMATp5Ae1VBaY/hPtTrWGuMJW27DqEJHuBUJ2WcHHlonucSvshRrrFSACCZ0BkCTrvrVStMcCxOTOLLFYLSCp8IJBOUGdweXKqCLJAHOpISt0hikiYJE6GNJHQ9auYfimIT4L9wc4zmJmZgmJkn3rr8OuATGnXX9K5Z4beZQ62nZTsVEzBg7eYqsZxl2Y3Lgni/dUNx2OvXsveOXy6LIGg00BA20GlScMxxsmQNZny2jUc6r3MO6iWRlHUqQPcinYLDm7cS2sAu6oJ2lmCifLWiUVJUyMWaWKW6BqcM4xbS/3l22XXKQQADqWUyATGgB+ladntBhgsZGBFtQIUDxgMTMHUEi2J5gms/iHZlrNzu2xOFD/lNwqR0zeCF+Zqpxzgt7Csq3QvjGZSrZgRtvUxioqkRkySyScpd2ZgECj7sxwW3YGa5aZ3KtJGU5YMKbJYAq4P4iQDMgkDUEinIxGxI9DFWoW0F3bvBNeK31tkOqReMplMAEXAAxOx6bRvFCNlRmUHaRPpOv0qY4u6QQbtyDMjO0Gd5ExrUNFEpBbd4Twst4cTC6+LvRO4gZCk6y2s6ZR1rlrs1g2YxixkyIQ3eWpzFrguArEgAC2dvxHUxQnXCKKIonx+HFu89sNmCuVDfmAaAdDGo1+da9/hloWe8ETtH9fPXyrBy1Ibz/AJjSckJSra6N+k1GPFGSnG7+EwnwfZy09pGK3Az20YQywS6zoD8/Y1h9o8Ati6Lahx4QTnIJnMw/DpEAVy3xfEKoUXmCgAAaGAvwgSNIqti8Q91s9xizQBJ6AQB7AU2jBRJwrh1zEPktjpmcg5UBMZnIByiiDtV2XGHw6XEktbbu70mfEYKXB0UyNP2l5zWZwbjIw6x3Cs2YEvIBIBnKZQyOXpsAfFV252nDAh8MrA7gvIOoOspJ268zM6QADVb9jsniHS24a0BcVWQFmk5lLqNEgEgNuY8J11E4ZOpMQJ26eVWUx98DKL10LEZRcYCIAiJiIAEdAKkk137HYgEBmtCc5+JjohhphOciPrFZPGuHPhrzWrhUssTlJI1AI3AOx6V1eJYgCBiLoG8C641Mknfcyfc1Beus5l2ZjtLEsY6SaA5NTB8HR7RuTsBInr110q7wTs/au2w7C74nZAVZQNCYGuvL3rCTGXAMobTpU+F4ziLShUulVDFgMqkZjm11B/Mf6ApGOE03uZu1WXBOEVjVPzxXgt9o+EW8PbtsocFz+IqQQAZKx5x7+dZGCwly8627al3bZRz0nc6Dbc1JjMbduhBccsEELMeEQqwIHRFHyqfhPEBYLHurdzMAIcSBv9DO3VV6U8wBXheyFr7MyEq164me3cPhyup8VogmBroTufF+UUBMsEgiCNCOh5iiRu1L/wDYtbAbGYERJnXb+PWsfiuNN9w7KqkKFhBA0nWOuv0FQCJezvDVxN7u3ud2MhbNpyIEakDWa3G7LYYaPiSniUeIp4gWtglcswBnZfEBqs7TQnlrgQVNE0wuscBwClu8xIjOQD31vVcqEEgA6kl+nw0I5Yb5+vPqNDSilFQwjw7CJrloW40zz9I3n1+grR7LYjDCwofEKjSxIZwN3eNPSD8xQZFSDDOdkY+ik/ypWLFsvk26rWevXFUbSdq8SEyfd5cpWMmXwmSQMpEbnUQaxLRAIPQipnwd0fFauD1Rh/KoSsaGnVZhjLa00bZ4wht93HzjcbRAHp7CtPs/xPCrZtI9wq6yHnvAI7xm/DpOU+4WhCK6BSoYowujVqdXPOkpJKr7BF2nx1q5h7Qt3MxJDMv5DkJP1uBf/wBZrN7LrOLw/wD5rf8A71qhUmFulHVx+Fg25Gxncaj1FNMoTcTFize7vEYG41zO5d1ut99JkOojxT0BET12r9sLDW7eERlZItOVRzmZEN0lEYwNQsDbTblTR2muj4WvL/8A0O3tmBrO4xxF8Qys7OxVYGdgxGs6EAaUUAuA4FcReW29wW1IYlzssIzCZ5SKIW7FidMSF1UeNQJzMi+Eq5zZc8HbxCOc0I1wKByoBhYnYa6c/wB8BlJAzWyAwCo2YeLY540B+E+lC2GUMyg7GurecbMw9CR6VxHIMjcVDuhmJpTTl2tX9GrxLhAtWs88iRr/AFIrQu9lANrrzOxtH56+/t5isC/jLjrlYyIiOg8ulap7V4mZ+7kc8p8pHxbaD29aXjjKK6nZp1k8U5J4lXHPFGVxXCdzda3mzRGuUruobY6jeiDsrhlbDXMmFt37zXsid4BCKLaszGSNBOwOs0PcQxTXrj3HjM5kwIGwAAHSABW72dey2Fe1cS4T3veI9t7aOjd2qyO8dZGh96aYmWhg4sXvtOAt2m7q49m6gKjOqk5WGc68x1jnQWb69fpSxNxc0AsUEhAdConeASBO5ANdW0Sp8RKAzPsOY15elU3Fkjttg0ROug0+VWlwN4xFm6ZEiLbGRpqNNRqNfMUsPgzmBjMAJ01BHVRtvuBzrSwvH7uGym3DhfBkuSwUZg4yEEGAUHtQphRj3EKkhgQRoQRBB6EHY1c/uy5lzaR11/T61FxHFtfutcYAM5kxMTAGkkwNNuVX/wC+fu+7ymJnl0jrVMkpqtpt0cNPLd6z+huH4Ffe2LihcpUMPEAYOu3XQ1X4nw65YIW4ACRIgzptW1gu0lu3atp3JzJby5vDDHKAM3OJE/7V9RmdoOIpiLgZLfdqqhQunIsZ09R7U4wss9ksHh37979p7q27YKohYMzs4VVGUySSYrT4PgLDXgl/hly3bLi3nFy8cjMYXPJgqTpm0iq3YnuiMQlxrqB7aZXtI7ujC5KsAgJEGK1+D5bd4PicbiLqK4ud2LN/xuNVNwFdADrl60FWAuLQK7qNgzAegJAp9nBXnAKWbjA7FbbMDvtA1+Fv3T0rmJbM7HqxPuSa2uHdp7tmwtkW7bIgMTnB1uG4ZKuPxZf3fMyEmOMBeIkWbpEgf5bbtGUbbnMsDnmHWmYvBXbUd5ae3O2dCsxvEjWiN+2mIPxJaaHVxKsIZckHwsOaA69TygVl8c43cxIQXFRRbnLkBGhCzMsZ+Ea70E2Z+CwpuNlB1q3c4O6uiFgC7BdRtPPeoMBie6bMBr6xV5uNv3yXSssjh4mBIECOnL2pEvU38fqdCC034zcv2p+93fBOOzJ0/wCoQg8wCfLrrrA/3CsbiOG7q41vNmymJiJ0B2+dEX+L3DSthRvpnJEFmZY8OmUt84G1DuNvG5ce4d3YtHSSTA8hMU85wRdi8U9mxiDbKLcd7VtXuEKiE96SzE6bAx5xVzCYHFu9wf3qilWgxdZpOu40C7bCs/shirS2cRau2RdW4Ukd4qERmggsRqDGoMimfZsCpINpn9cWgjyELr9aghhDhMdh2yziVByLrnU6kQwOaYOYgkaaJsKA77947NtnYnXlmYnX3qIGlUgGFzAYZlOVbZnPBEbEtHty6RUFzhVo3QFs5kIaIYiQbqANM7KjH1g9AaF4roNFEmv2m4fbsm3kBGYMTJJ2Kgb/ADqx2Z7Nfa7TP32Qq+QLlzE+FTmHiH5v4ddMFmJ3JNcC0AFo7D3CJF8fAXytbK3NAhytbzEq3jg7wR51T4v2UuYfDm+biEDJKwQ0uFIHqM46bGsJLjLsxHoSP4U98VcIg3HI2guSI0MRO2g9hQBLwzCi4+U1oX+CAX7dqTLmJAk/CW0HM6DbrWRYvshld6tW+K3RcW4CM6mQSJ1ylevQmkuM99p8G+OXT/jbWurnx/psN2VGkXmgzvabQrvz9fah17BFw2wZIYoDtJzZQY5Vtp2sxAbNFqfF+EwczKx0zfshfQnrNYdlyrB9yCG15kGdacYFZoPwK+OSnbZutRJwi+xIVQSDlPiXeFMCTr8Q+vSro7Q3PyW+XI/wmm4XjpRswtLMz8R6II9kHz+oHJkXbRVipHiUlSN9QYI89aku4K6olrTqNiWRgBJjUkdZ9qV+8WuNciCzl46Etmiji5jrmLwVy85AYtlcLIHxqVhSTyVBS8s9isbjg5uvgx+zPBUIGZAxnQsAY3opHY21cU5VCEiJX+fWs/CYtrKqXtr3c6+MZ4mJCH9Zo44Ni7dy2HtuGU8xvPQjka5rnPdus6cYY9u2uTzHjHZDEWmYo+bUnciZ1PXeh/iGHuW5zqF5nU+wkachXsvGG8JlfOvNe2bCNdt/Q9abizSlLaxWXTQjDcgduWHt5Q6lSVDAHodjXe5aJytG8wdok/Qg/OrfG8Ul67mtAhAqqoO4hRI9AxYDyArXs8asBAsPooU6DkioOfPLXROaDvct+VvY9Y/iD7U0qQYOlEX98Wjca5muaxpA1g3TlOu33i7fl9azOP4pb19riTlIXfQ6KAfrNAclK1cKnwsQfIx/Cn98352/eNEmE7SYZbNu22GlkRVYxbIuQgVs+ZSQGMSRr4FjnVn/ABRhCQfsmUqbhAVUIOc3ImTMjMDExI0gRQQBtTLhnIkL9RV/tPxC1iL/AHlu13SlQMsKNQTr4dDII9o5Vc4dxW3bslDBJA/5n+GlJyznFLarN2iw4srfqOq+aMizw684lLTsJIlVJ1G409RUeIwN1FzPbdVmJKkCenroaKOz3FsNbtZblxlfvXba5BUpAJy/tBfeq3ajimHu2LaWmctmBcHNAhD+bSSzcvy01N0Y8iSm1HtfAMKCdqebD/kbePhO+0euo96ucExCWrhd5jIwECdWGX+BNbrccsa+JtTocp0hlYMRzGm29SVBcYdzqEYj/SfQ8qiZSNOnKijh/GLFvd3IJOmWYBuO0zzJDCfQUN4xs7OR+JmPuSf50BZDmHlTgpOwJ+VGd/tqhAjDsI5C4AreFly3FyeJTmkgESVFPsdv8s/9MNWY6Pl3dm18Jk+LU8zJ50EWU+3d83LeFZ7SW7kXluBMsFla2JBUkEc9zEkUL20LEKokkgADmSYAFb3bLEWCuHtWbdy2lpHEXFyklmUk76mQST51g4a8UdXESrBhO0ggifLSgkutwXEjU4a7yH+W25MAbczUX2C9p9zd1BI+7bUCJI01Ake4rZHbTE51uFLRdSYbK065cw+ONQijblprrTv8ZXTlz2bbMqMgbxDwsFDSAcsnIvLlQQD122yHK6sp6MCp9jrVjDYJ7glRPv8ApUnaLjDYu73jqFbLlhSYjMzDfb4v586m4LxUWRqJ0Ij+cx5/Wl5JSUbirZr0ePFObWV0q45rkgw/DL1xiqJmIAJggQDIG5HQ0+7wbEKCWssMozHbQRM71f4TxiyjXmuBj3luFIGoYBzO4jUqJ9a0OJ8fwz2rypnzMCE0KggoqwRMAeK4fVR1q8G3FWK1EYRyNQfF8eQPaiXjHCcFh+7V795rjIrsttEOTMAdSxHtvt1oZbnXoPGBfHiwzYa7bui2zK3cM6uttUIOf4l0G8kbac5FA3xnhFi3h7WIs4hrq3HKEMmRkIUsQdTr+oNYtF/bK264a211rXe3bzXGS1lyoO7ygeHc9WM7xJihrhT21vW2urmthgXWJleYjnQCKsUqL34hwoz9wYjQBCrA+KZfMQ2hQDTdSedPTEcHzOWQlWYEDJcBVe7VSuh/OGafOiwsDa3OzWPKhrDKStxlYfsspBM+RAHzArEtXkDjxCJ8zz9K3sJetviEyHTKZ3jNIjXmYms+eXFUbtPhTg8l8p1R6Jh8BbuiHUMuhIIkHXMARzg1yy9u33rW0UEsBoIBcmJgae3So+EY2FAMyR0qDFIRbCQc2bNm0g85Osj0iuam2qOjUbspcY4XdLB+/uXFKmUZiPFOgUIRCxuTPzrDfC2rJuXLh+7sqGVCSSxYwqKT6HfaR0ov4jikVM0jb+vWvL+0XExflFJEO7MDsYCrb9SAH/ep+G5uvBl1G3Gr8lC2xIk7nX3M06mLounIUZjs1giVjGCCQC3eWoXUaETJmSoI5iTpXTOXYHilRfh+y2HbJ/1YysisWDIIYlQRB8QADE6gHTWhvi+GW1euW1fOqmFb8wgEHTTnRYIqUhREOHWe57zTNMRHlPSfKrvDOB2Gw9u49oEtbZ83eOPhPMDQHUH0pWPKp3Xg16rSPT1buwRmp8FhLt4lbdt7hAkhFLEDaTHLWtTtdw5MO9tFTKSpZhnLT8Mb7a5h6g1L2NxDWkxbo5Qi0oNxVzFFN1A7hZElVk78pppjKJ4BjP8A8W9/6TfpWdcQgkEEEGCDoQRoQRyNFvBe5tYgPYx117huoqobTfegnxBzm1Ea5iBl6TsNcab/AKi9/wCW5/8AI1AFWlWj2d4S2Kum2rhCELyQToGVYAHPxaddudbX+Cbh2vqIYKcyMmuk5cx8awwgrMmRyoAFK5NFdrsRdbNN5QVZxqh1yEDNvMHMDsaE7WpHmRRZMI7mkhGuURPwm2LQuSNeU+UxM+X8oqfgnALd2yjm25LZtQ4A0uOogT+zS8WWOS68GvUaOWCtzTv2sEqVFXEsFw1cO5t3VN0IpUC4TLQufQkjfNpptp5jmB/zF/rkavJ0rM2KG+aj7tL+SKK7RJxEWe6GX4spny9dfXrtWzhsHbXDozLaI7kOT3QJEWsxLGfUT1y0rFl3puqNOr0q07XN3f8AQBUhRH24wy2mtIBbBhici5fyrrrr4luD/b51icPwrXnCLAncmcqjmzEAwvnTjGQTSr0rg3B8LZsm25zd6pS8x1KmTkuWzErbJGnOSvMGvPMfhWtXGRtcpIDDZgDGZTzBoAgq8eK3iILA7DW2hOggS2WToKn7N8OtYi463LvdgJmBlRmbMqhAW0k5j/Haa3F7K4YsB9rC+LLBKEkZbjB1ykgK2QQGg7zqQKLAFL99m3C/JFX3ygTTJoqxXZW0li5c+0eNVdgnhObK1wKBB3KoDptmoXw5AMsJEbedDfFl4JSko3XycAmpsPhwfjGvIanT/SNZ9qltEQCoOp2AGY9f9C9KZcbK0AgEnVV32O786zym5OkdPHp8eJepLn/h23h8oInJJ3ySTOo3naPrUthiWALsDICsQFgzyWqTOeRMzvNNu5jrJJGoJM+lQ8Tfdh+djiqjF12rwejcEui6rW3gOp1G+sSCPI6EeRq7fS4BBbKBuc5OnkDoKErF/vkS9bcpdQBWKwZHRlOhI1j1qfENdukK2IzJzy2+7JHQkkkVjca8lo5XXuM49xVSSluT+Gdwp5sTtMct6H7KApIyt88rQAd+pqx2gxKM627YAS30/N0qol5mieWogAEfOtEMb22isdRiTany/q0M+z5QzScoOkjly1FQqwNXC4IIygdSFn94cxrUOPt5WlQPMDTXYkDpz060+E3dSE58EJR9TF28kWldrdwnZ9LtsXEvkiAT900DWDrPIhh/trN4xge4uG3mzQAZyld50g604wWV/tDfmPvUiY66FyC7cCwVy5zGUxmETEGBI8hUeDwz3XW2gzOxhRoJPSTpWz2h7NvhrNq5mzZiUuCI7u4J8G5kaHXnE8xUUkWnklP9m39sx8TiXuHM7s52liWO5MSfMk/M1p9luMHDNcIYLnTLJt94PiBgrmXSJ51jVeXg+IK5xYuFcuaQhIywGnTlBB+dSVNrBdoksPntJYRvzjCkGDvAF7w+gobxFwu7Od2YsdI1JJOnLerB4XiJA7i7JJUDIxkrOYDTUjK0jyNV8RYe2croyNEwylTHIwRtQRQxXI2JHoYp5xD752/ePy5+Z967hcM1wkLvU/8Adl3OqADMxgDbkTz8garvje2+R/42Rw9Sun3IDjLv/dufvt8ufkPaoQ2s8961G7PYkR91vtDLr9azr9tkYowhlMEbwRvqKsJTrsS/brkRm06cvarGD45iLSC2lyFWYGVTuSx3HUms41p2+zeLe2lxbRKPOWG1gQJIG3z10NQoxj2QzLmnkrfJv7Zk0q2f8P3NfvbWgn4j56DTfTbzrFBqRQ7MetKaMODWicHaWzhLV28/eu1y4itkRbjKJzbkxAHlVnhtm4EdcVgbID2rnd3FtW1ZXVGaGC+Skg+nygG2+4DzVrh/ELtglrbZSd9AdtQRIMEdapCtLBcGxF1A9uyzIZhpAGhIOpI2g+1SBa/xLidu8WIiO7SI5geHSedU+KcTu4gqbjBisx4QNzJ2HkKkfgeJUMTYcBYLTAiSVE69QR8qjx/CsRYAa5aKAnKCSCM2umhOvhb2PSgCnTqscOwRvGFOtWU4Qxud2XVTBJLaARH61T1I7tt8j/xsix+o10/ZmwKeqyRz8v18q7xG0LbZQ4eD8SzB6weY86YDAEfIc46+s0SZWCrqaHs0AhSddz16j0pWwM3yqIP1rhub0JJETm5dydxrXLbawa47/D8q5cOs1YoOs3nssWVis6HmCOU1av8AFnZcq6TuRv6Dp61Vdpp1tdvSaVKEW7aLqckqTGhABUls1JhcK10mNAB8R2H9H+Vdv4K5aknVdgw1Gsxr8qZZQiV8pVulOdZ1G3Tmo8vLyqC62w8qfZuc6q482Px5XFbX2LfDeKXcNPdwQxViCJUkMrSNRvlAI6VBxLGvfuNceMzRMbaKF/lUd7yETy5E/wBTUM8qtFlMkUnaCHs3xexh0IYXc7EZyoBDKGJjVgRoREQQRMkQBq47tNhr6PbuPeK3CC4yJ4iCuUkiYIC7iDoOlBM0pq1CqH3Ik5ZyyYneJ0nzitm32pxCoiRaIthQhNuWTIpRCDO4BbedXb5YdONtvyn2NRwXjCUuysIG7ZYkxnW00FiCVbTPnDAQ40h2A8orM47xZ8VcFy4FDBcvhBAgMzDQkx8R/wDus7MOtdmpKl3hWMFps0dOQO3LWr68ZQ4i3cdCyqSSsAzKMoGu+pnWsImNa3MX2XxNoKbgtJm2zXraz6ZmFLeOO7d5NP5k1i9Livrk107R4TMAbTZD3k+BQRmdcsEHWFznyMChLG3s9x3iMzM0dJYmPlNWuK8FxGHVXu28qsYVsysCYJ0yseQNZtMMqCrslw1YW8wVmLL3fib7ts5XM1sIRcgiSsiFMmJkG9jiro1xltgqzfDngBgBmYFgAQwK6CYIaTJIHjpUdK5lHQUBQT4ntYCtwLaaXBCszCVJQLJ/3Kp/20Lg02kDUBQY4C3ZvYKyjLeW5bNzLctIGENcYsp8Q01Gmh+W/eF/ZsNautF+5cNp0RiiolsMDOUZzEnc+um9B00qCKHitXA8fv2rQtKUNsT4HQODmJLTO8z/AA6VkTXQaLJo327WYsghnVgwAIZARoSRA2Bk/QdKrcY4/iMSoS6ylQ2YQoEN4pM+eY/SsqaU1NhRe4djjZMqNd9/6mtfhbvdY3GkZgyf6gx8Q9DH8awMJbzHXYb/AKUWcIuoSBIHIDb5DrWLUNR5iuTpafJOUNkn0+1EeM7N5xntaH8SHZh0U8vTb0ocxgZWKupUjdSII+VepYcKood7X4mwE+8UMQdOTb6hTuJ9utJwZ5XtfJbU4k48OgCxVyNqitnSpcdhGDjUMrDMrjZl/kQQQRyINQJtW85gT9kcXYtkPcjvAYQtML0IOoU6zJE+EAESZqcXwoFxwpGXMSux8LHMuo8iKzMK2hHz/WriuBzFWQESAjzpzPyptxwPhMnyrlq2fiO9AG9wC+MqoDmKrdbu2AADg5raifiDZiekkfNvaC6oa4hBksjJB8Cyg73Tn4ww8vKsrD32Qkqd9xyOka1Xxl8sZJJP9aDoKigIcQZ1mn4ckgGq5ar/AGYNvvwtwAqeu076jnzqspbU2WitzSLXDcFcvHKilp5/hU9c2wrSxXZd1Uk3BnI2A0n13orwbjSAI5Abe1PxYkVz56mTfTwdOGnjsqXJhXu0GCDjNgoyt4k7u0QdQR4txEFoGhLEHQCoLHGOHeAthCIRVK91bYEgoWbMWkkgMJInWqnaXByM6jUb+Yodmuhimpxs52XFslRd4tdtved7a5LZMqsAZRA0gabztp6bVrnFWe5y6Z53kbRvPr+lDRNImjJjU6vwP0ureC0ldh1wu/ZXDW5uqYtOzKSkqwVTEHX8URvPpWR24KK9pEZGhSSUAjcLqQdTmR/lFDc0pplmRnW1EUZdr/swxFwYlcR3udcrKy5Day+EICNhz5zMHcUGTRLiu1DPu90wZAdbNwD0zW5+tBDHceK/YbYt973JxDG13sZsndmcsfgzEx86GrKZmVepA9zFanHuO3MQqI9xmCEkAoiRpGmTfSsjNQCCy92LuK+QX1JJIH3bhTlALS4kLoRvuZHKao43srdthSz2/FmiCeRjkI6Vipirg0FxwN4DsBMyDE9dfWp7PFcSohcRdA6B2A/jQHJZvcKtiy9wO/hAIBgbnSdJ2j61T4PhBevJbZ8gaZbpCM0/SobuOusCGuEg7iYB1nUVACDQAWXuzFlZnEFYUnM2XKYVzlEEtPhDHQ6NprTh2awwchsR4IWG7y2JYuyvyOgUKdhvQjlHSuxQFMt8WspbvMlt86AjK0gyCoMyNDuenoK1+Gpa7qX3AEefp1P6+47Twx6n3pWSG5VdGzS6hYG21dhZ2ewSOlxiqEi4FhrYYwQgMa/tbdYp3aLDW0w7sotSbmQZUCsCLhGmug+7ue3nQjNJTBBpi4VGact03L3d/wAmxhLYBC8udXr1pY+GP51W4deRjof66GtW1BEc65eRvcdHHFbeCtb4xftqfCXAHhnf350K4+/cuuWeS3Tp6DkKNFtjNH9AfyqXhvD/ALTeW2oAG+uwUHUnzJ0pmPKoc0VyY3PizD4NwS5dt5CjKT4rdwghC3NCeQYAQeoHzH7yFWZWUqQSCCIII0II5GvoVLeS2qldFESo203Hl6UO8T7I4W67XSmcP8QBgzyZWGoPUTBq0NXb6kLnpOOlnjSMQatqwI0gjp0rZ7e8Fs4S6gslyjKT4jOoPI/PblFDwQnYGtcZKStGScHB7WXEEfhpzP50uGcOu37i20BZm2H8z0Feq8G7L27FoWgqtdufG5AYheZE7DoKpkzKAzFhc/hHktx4qtqdq9b412Kw1wMbNsKV3kmGPMCNjQu3Z22QUUFHBgjUHoRr5UqOqgxj0kl5AxkgTy68veprtgnxLuI26yIjzogxnZlsNdUrcDrEyfCZ00KHUiduREcwQCixwwTqtTk1EY9uS8NHNpSkmk+3yD3BuLXFQBllvXSr12/dun4wB+UA/wASNa3xgLY6VHdsKNqwuSbujYoNKrB1rLHdj86qYbgdq4G1uBgZIUrGWRqFIzc456x1ogvYc8qweM4p7EPbbK2YToDoCGjUdVB+VaNPNqVe5n1OO437GLxvCLYum2CTAE5omSJ1jyj3qy3ArkTmXaY16TG1ZuNxLXXZ3Ms2522AA+gFXhxy/wDsn1X/AJronNG/3TczlJSQB+LrmgDTeFJ9IqrjcM9psjgZt9DNWk4u4bN3dudORH5zI13JuNPrVbiWLN585ABgCB5CKAIbdt2nKrNG8KTG+8bbH2NcdCPiBHqI8+daXAONPhc+RFYPlzBp/DmiI82+kczWrY7aMpWcOpCknW4WbWSfGwJ5n5QOVAArmHWnKJ0G9Et3tJZbDtZ7hhKFAxKtlPjhthrLDaNp5Ch3CEB1J/rQ1EnSsZjipSUX5aRxrbDdT7VESOooix2JtNb8IE5TPry5a8/pW1g7AFm0QbZm2nxLMeBZG45z9KXhm522qH6zBHDW13Z561NWr3GbIQpGxWfrVXCgFwDtNWZlESTS1rRNhOopvd2xGo2/SpRLbZmvXVXyqTHZc5y7U/DsANarJ0XhBSfLG2laCAPWuNZYSY2qxg76qWnmKsX8WhVh1FXXKKyVOkU7Yk6GKspirqHwtPrWfaeDRL2VNjvct9cy6ad3nB85FxCvyPypLjbGQnwP4V2gRCe9QgkaMNYPnzijT+zZQBdcrIIVflE6eVaPDuzvCMQISzbLdMzhv3WIb6UQcN4Fh7AC27ZQDkGJ/wDcTScun46R2PUU+o7b1PhP+06D/iqmOuKp/KwOp2Hz5Gth8HbO+b3g/IgVCOGWfxJnn/uHPPyOn0pK0svI56qPg847Z4J8cq28OEZ0dmaWCk+EKAkiCD4pM7rB5UD8Q4LjcP8A5li6oHPLmX95ZH1r6Du2bQiVQR8OgEenSojcRTpJPSNflNb4QUY0YJz3ycmA3YHgNzBEXb1xGNwAZRqU3YeLmTttvG9GGGTw6EF7mpI1yr/R0qziuH2bwAuWUcftqD5jcaGsy52Sw4Ja016wxETauNEdMj5lj5VmnglJ3ZphqIxVJFw5ADqFtWwZYncjck9POg/H8cwlxnud8hA0AkTp1q7xbshjHstZTiOa2Z8Fy2AdeRuLuJ/ZoGxX9nGPt692twDnacN9DDfSojpq5kWeq8R/sfxftRae4h8TBQAcukxruajPa4MfDaaP9VZWK4U1lx3tp1J5OpUn3FTrZA2gVXZjj2RpzZs89qk1SSqvY1k7QnLItMD5v/8AdVP79xBPwoPc1AqKNzNRXLijaoSj7CXKXll3+978GXUeYX9ZrFxly5cEFs2szFcxGIFK1eCjfUmnYoc2Jy5OmrM+6WUkGreEw2e3mnnFV+IPmea0uFv9xH7Zn2FakzIUnwzBS3SqveGttG+6uf6DWAaGwJM5pZzVzB2FZJJ11p74Icj0+tQBQzmud4fKpsbhigHnUNlJqG6JjFydI6HNOZxyEUmt6gedSnDHpQnZMltdMn4+dU/01mqdat3C7ROsbVXFw7QPagqda5Tc1WAfIe1INrsPagCqa6KnvXMpjKv7tTYVgRJVPYUEplMGumtB8vRPYVWxuWBET5CKCCsgqdWJMxTLBA3qfD3ACfSo80M21GxHFXEIIZl9CRRp2P7XYoBlN9ny7LcAfTpO/wBaDcTcVlIFRcNxbWnDD5+lRJOuAhJX1HtnD+26n/Nslf2kMj90wR7mt/hvG8NiNLd5C35ScrfumCflXjq462wHinSayuJcYzAqgjz+mlLhOb8DckILlM+h2srzAnnpTWsDKV2B6eH2Ir584R2vx+HgW8S+Ufgc519AHmB6RRjwf+1lxAxGHDDm1psp/caQfcVotGY9Lt8PVTMtvPxH+XLyq1FeVcV/tacyMPhlXo1xix/cWAP3jQrxHtvxC/OfEso/LbAtr6eEAkepNVSUeyLNuXc92x2Os2RNy6lv/UwH0OpoU4r/AGkYC0YQ3Lp28CZV/eeNPQGvHMbxG5cJk77+frVQmhNg6XY9D4x/alfcFbVi3bUzBf7w+RggL8ooEfGuWLE6kyeXOduVVSKcKhpPuCk12NXC4hW33p2IIFZIeNqnw7BjDFvlH86X6fPA31eORlxpNdYedWThrfV/p+lJkTq/0/Smx4FSdlB96vYN4tnXc1DFo/if2H6VNnt5QJP7utBFDhiIRh1FZhrThCCPrEH+NUb6qDAJPr/xQQct3CBUn2g1H3ZppFAEuKvlgAeVNwzxUbUgahqy8JbZWWu9GcHzmroxQrJmu5qEqVBkk5O2aC/yrMHxfOu0qkoT00b0qVADcTyp+H+GlSoATVHdpUqAGrTl3pUqjyXf6nWqNaVKpKeTSwP4/wDxNWeKVKqx7lpHK6KVKrFRCumlSqSRGnJSpVBAwUlpUqCULnU2B+IUqVAMvHf501/hNKlQQZ6b09qVKofcav1Y5qrtSpVZih67UmpUqgBjUlpUqAFXaVKgGf/Z" alt="">
            </div>
            <div class="down-content">
              <a href="blog-details.html"><h4>Ronaldo resmi balik ke Manchaster United</h4></a>
              
              <p>Nullam nibh mi, tincidunt sed sapien ut, rutrum hendrerit velit. Integer auctor a mauris sit amet eleifend.</p>

              <ul class="post-info">
                <li><a href="#">Cristiano Ronaldo</a></li>
                <li><a href="#">02.04.2020 16:20</a></li>
                <li><a href="#"><i class="fa fa-comments" title="Comments"></i> 12</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="blog-posts">
  <div class="container">
    <div class="sidebar-item comments">
        <h2 class="text-center">Testimonials</h2>
      <br>
      <br>
      <div class="content">
        <ul>
          <li>
            <div class="author-thumb">
              <img src="https://akcdn.detik.net.id/community/media/visual/2022/02/01/kylian-mbappe-2.jpeg?w=700&q=90" alt="">
            </div>
            <div class="right-content">
              <h4>Kylian Mbappe<span>28.03.2022</span></h4>
              <p>Saya sangat senang menyewa mobil disini dan menggunakan aplikasi berbasis web ini, karena memudahkan saya untuk menyewa mobil. Terima kasih Progresstination Team!.</p>
            </div>
          </li>
          <li>
            <div class="author-thumb">
              <img src="https://awsimages.detik.net.id/community/media/visual/2020/11/11/anya-geraldine-7_43.jpeg?w=700&q=90" alt="">
            </div>
            <div class="right-content">
              <h4>Anya Geraldine<span>15.04.2022</span></h4>
              <p>Aplikasinya keren banget, bisa menyewa mobil secara online tanpa harus dateng ke tempatnya dan pastinya aman dan cepat prosesnya.</p>
            </div>
          </li>
          <li>
            <div class="author-thumb">
              <img src="https://cdn1-production-images-kly.akamaized.net/Id4BDEYy4Ke_Yz_aPUkPZRPH3Zc=/1200x1200/smart/filters:quality(75):strip_icc():format(jpeg)/kly-media-production/medias/3902015/original/072005900_1642033000-Ghozali_Everyday_OpenSea.jpg" alt="">
            </div>
            <div class="right-content">
              <h4>Ghozali Everyday<span>10.04.2022</span></h4>
              <p>Mau nyewa mobil, gausah khawatir. Karena udah ada aplikasi Progresstination untuk penyewaan rental mobil secara online.</p>
            </div>
          </li>
        </ul>
      </div>

      <br>
      <br>
    
      <div class="row justify-content-md-center">
        <div class="col-md-3">
          <div class="main-button">
            <a href="testimonials.html">Read More</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div style="height: 180px;"></div>