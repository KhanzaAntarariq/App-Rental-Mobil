<body>
  <div id="app">
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
            <div class="login-brand">
              <img src="https://scontent.fcgk29-1.fna.fbcdn.net/v/t39.30808-6/290618007_5387550777967954_6023857292583497416_n.jpg?_nc_cat=100&ccb=1-7&_nc_sid=730e14&_nc_eui2=AeHrK5g8plqlPk_xI7q68mpXARxllCYdfZ0BHGWUJh19nZwdsj8Qd7k9DBJboPc1eRIAfHS1lh-Zwv60bnBEK-B4&_nc_ohc=hzH-E5phrzEAX8C5wYB&_nc_ht=scontent.fcgk29-1.fna&oh=00_AT_P3QaLeyZjkaPBfeamf-tiMH4piRORnkktxLWKZMvthQ&oe=62BE933C" alt="logo" width="120" class="shadow-light rounded-circle">
            </div>

            <div class="card card-primary">
              <div class="card-header"><h4>Login</h4></div>

              <span class="m-2"><?= $this->session->flashdata('pesan'); ?></span>

              <div class="card-body">
                <form method="POST" action="<?= base_url('auth/login'); ?>">
                  <div class="form-group">
                    <label for="username">Username</label>
                    <input id="username" type="text" class="form-control" name="username" tabindex="1" autofocus>
                    <?= form_error('username', '<div class="text-small text-danger">', '</div>'); ?>
                  </div>

                  <div class="form-group">
                    <div class="d-block">
                    	<label for="password" class="control-label">Password</label>
                    </div>
                    <input id="password" type="password" class="form-control" name="password" tabindex="2">
                    <?= form_error('password', '<div class="text-small text-danger">', '</div>'); ?>
                  </div>

                  <div class="form-group">
                    <button type="submit" class="btn btn-primary btn-lg btn-block" tabindex="4">
                      Login
                    </button>
                  </div>
                </form>

              </div>
            </div>
            <div class="mt-5 text-muted text-center">
              Belum punya akun? <a href="<?= base_url('register'); ?>">Buat Akun</a>
            </div>
            <div class="simple-footer">
              Copyright &copy; Progresstination 2022
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>